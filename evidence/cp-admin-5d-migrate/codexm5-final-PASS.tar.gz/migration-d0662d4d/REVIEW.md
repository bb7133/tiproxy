# Independent review — PASS for the three migration metric families

Final reviewed implementation: **d0662d4de0610fd90563a0b6426404efca31199c**.
Scope: pending_migrate, migrate_total, migrate_duration_seconds, their retained-state lifecycle/capacity, original publication regressions, and preserved overflow diagnostic visibility. This is the migration slice of5d, not all remaining5d families or a merge authorization.

## What closed

- Accepted/settled migration state is authoritative, not reconstructed from lossy notifications. The original four router paths retain exact-once settlement/publication checks; dropped terminal notifications cannot leave a permanent phantom pending count.
- Per-incarnation pending sums cover current and session-retained old routers; cumulative history and known-zero labels survive destruction of the final router. Outcome-specific histogram history has26finite buckets; duration labels collapse reason as Go does.
- One global4096retained pending-label set admits keys to every ledger. Thus local maps and their aggregate union are bounded by the same set, without independently choosing different subsets or affecting routing admission/settlement. The churn regression that lost a real pending count now passes.
- Snapshot acquisition precedes registry locking; immutable local snapshots render directly without overwriting shared registry state. No router/registry lock inversion introduced.
- Final diagnostic-only delta includes retained-history drops in the existing saturating exporter sum for tiproxy_server_event{type="rust_metrics_observation_dropped"}. Source-reviewed through ExportTotals delta emission; the new accessor regression passes. No claim that this new diagnostic was exercised by the older process smoke.

## Independent validation, with exact versions

| Revision | Validation | Result |
|---|---|---|
| ccb30b4b (same implementation as c1e4f826) | control-router131pass/7ignored; dataplane72pass; tiproxy-rs95pass | PASS |
| ccb30b4b | original6andnew3reviewregressions; realshared-label/retired-router sum and zero-live-router tests | PASS |
| ccb30b4b | fmt; clippy on3packages/all-targets/all-features | PASS |
| d0662d4d | solechangedfileobservability.rsdiagnosticdelta; dataplane73tests includingnewoverflowaccessor | PASS |
| d0662d4d | fmt; dataplaneclippy/all-targets/all-features; make dataplane-metrics-parity | PASS |

The final delta touches only one file and adds overflow accounting plus its test; unchanged router and binary suites were not redundantly rerun. Historical fd36/a14/f315/788 first failures are preserved in the prior review archives rather than erased by this verdict.

## Basic process evidence, explicitly not the final head

Author's T3 run64340 used **78893da29bbadcf951ec037dca1b9c605c58d538**, before the last capacity/diagnostic fixes. Rawharness reportsEXIT0, localredirect/directForceClose/freshadmission afterbridge disconnect. Reviewer independently verified remote binarySHA **721e1726a6b79c165ff50a2056df7579f03dd9755679413f654aae40b2f53047**,mtime2026-09-21T17:20:10Z,size88111544bytes.

Full475-line /metrics bodySHA **57593061d292a183b13a8838360d97c05f0ad29d5aa5b30908b9dae25bbdd6aa** matches local and remote. Independent recomputation verifies26finite+Infbuckets,count1,sum1.334333042,total1,pending0, including everybucket's value and labels.

Later source changes are limited to retention admission, cumulative diagnostic accounting, and tests; their affected behavior was independently verified with targeted regressions. Under the agreed basic-smoke scope, no duplicateT3 or expandedmatrix was requested. **This is not a claim of a d0662d4d process smoke.** Prior59625four-lineexcerpt was superseded for fullresponseverification, not reclassified as complete evidence.

## Review handoff

No remaining blocking finding for these three families. Home retains task108implementation ownership and can continue its remaining5d scope. Task102is the broader ongoing Rust-work umbrella and is not closed by this slice. No reviewer push, PR publication, merge, deployment or production operation performed.
