# b_conn independent review: CHANGES REQUIRED

Exact implementation head: 2f767f06cc3f1b4b6174417a35240fcf70cf2421.
Review scope: existing b_conn zero retention, physical counting, bounded shared admission, and the declared Go/Rust shared-address divergence. No expanded integration matrix or runtime rerun.

## PASS evidence
- Clean-head control-router library: 136 passed, 7 existing ignored.
- Clean-head Go pkg/metrics: all tests passed, including TestBackendConnGaugeOverwritesAcrossNamespaces (actual global GaugeVec two Set(1) calls -> 1).
- Rust migration_snapshot_sums_shared_backend_address passed in full original suite (two real router incarnations each holding one connection -> 2). MTR-007 now references these existing fixtures, not the previously nonexistent comparator.
- Exact original reviewer regression review_b_conn_retained_incarnation_and_final_zero copied unchanged from the archived e3a2c975 patch: PASS. Real plane same-address current/retired incarnations -> 2, first close -> 1, final close -> Some(0).
- Source event registration is at successful initial connection / successful migration application. Original package tests for between-scrape zero retention and migration landing both pass.
- Added capacity regression confirms real routing still admits all 4097 sessions; known addresses stay 4096; labels_dropped=1 persists after all sessions close; retained address set persists.

## Remaining blocker, newly reproduced
review_b_conn_admission_bounds_live_counts FAILED:
known=4096, live=4097, dropped=1, real_active=4097.
The test constructs 4097 distinct backend-address sessions through actual Ledger::open/reserve/finish and then calls physical_connections(). The 4097th successful real connection is correctly not admitted to the known metric address set, but remains in the live metric map. Assertion actual=4097 expected=4096 fails.

Source trace: Ledger::physical_connections in ledger.rs unconditionally inserts active addresses; RouteLedgerDiagnostics::migration_snapshot in plane.rs then uses backend_connections.entry(address).or_default(), so an address refused by shared metric admission is reintroduced. This aggregate consequence follows directly from source; the new failure reproduces the live ledger map, not a separate process scrape.

Requested fix: govern active metric map entries by the same b_conn family address admission, including per-router temporary maps and pull aggregation. Preserve physical routing/settlement and persistent cumulative overflow. Do not add a second arbitrary address limit. Remembered-address capacity and migration triple capacity are distinct family sets; the remember_backend comment about the migration label sets admitting the same things should be clarified.

## Evidence hygiene
regression.patch contains reviewer-only tests, no production implementation edit. Original zero reproduction is unchanged. Capacity fixture initially hit unused-qualification compilation lint; *-fixture-compile logs/receipts retain that reviewer setup error, not a product failure. Corrected fixture's actual assertion failure is capacity.log. All test processes ended and only reviewer test edits restored after recording. Historical e3a2 first failure remains untouched. No implementation push, PR, merge, or whole-5d qualification.
