// Copyright 2026 PingCAP, Inc.
// SPDX-License-Identifier: Apache-2.0

package observer

import (
    "context"
    "net"
    "testing"
    "time"

    "github.com/pingcap/tiproxy/lib/config"
    "github.com/pingcap/tiproxy/pkg/metrics"
    "github.com/stretchr/testify/require"
    "go.uber.org/zap"
)

func TestReviewSQLDialExcludesDelayedGreeting(t *testing.T) {
    listener, err := net.Listen("tcp", "127.0.0.1:0")
    require.NoError(t, err)
    defer listener.Close()
    done := make(chan error, 1)
    delay := 400 * time.Millisecond
    go func() {
        conn, err := listener.Accept()
        if err != nil { done <- err; return }
        defer conn.Close()
        time.Sleep(delay)
        _, err = conn.Write([]byte{3, 0, 0, 0, 0x0a, '8', 0})
        done <- err
    }()
    cfg := config.NewDefaultHealthCheckConfig()
    cfg.Enable = true
    cfg.MaxRetries = 0
    cfg.DialTimeout = 2 * time.Second
    health := NewDefaultHealthCheck(nil, cfg, zap.NewNop())
    addr := listener.Addr().String()
    defer metrics.PingBackendGauge.DeleteLabelValues(addr)
    started := time.Now()
    result := health.Check(context.Background(), &BackendInfo{Addr: addr}, nil)
    elapsed := time.Since(started)
    require.NoError(t, <-done)
    require.True(t, result.Healthy)
    seconds, err := metrics.ReadGauge(metrics.PingBackendGauge.WithLabelValues(addr))
    require.NoError(t, err)
    measured := time.Duration(seconds * float64(time.Second))
    t.Logf("healthy=%v sql_dial=%v stage=%v scripted_greeting_delay=%v", result.Healthy, measured, elapsed, delay)
    require.GreaterOrEqual(t, elapsed, delay)
    require.Less(t, measured, delay / 2)
}
