# Backend SQL dial prerequisite: CHANGES REQUIRED

Exact head: 9d6bf6dbed924538bb00444157cbcd02aeb41cb9.
Scope: last SQL dial timing field only; backend four metric families are not delivered/qualified. No broad boundary matrix or integration/runtime rerun.

## Independent evidence
- Unmodified control-topology library suite: 252 passed, 6 existing ignored.
- One equivalent scripted loopback fixture per language: TCP accepts immediately, then waits400ms before sending a valid MySQL greeting; no retries.
- Go real DefaultHealthCheck/real PingBackendGauge: healthy=true, dial425.583us, whole check402.59625ms. PASS.
- Rust real ClusterHealthNetwork::probe_sql_port: healthy=true, sql_dial403.517375ms, whole stage403.7205ms. FAIL: sql_dial should exclude400ms greeting wait.
- Fixture server tasks joined; no production edits. Go file and Rust patch included; raw logs and command/head/exit receipts retained. Worktree restored clean after sealing.

## Root cause and requested fix
Go health_check.go takes start before DialContext and sets the gauge immediately after that call/cancel, before SetReadDeadline and CheckSqlPort. Rust backend_health.rs starts before and ends after SqlGreetingProbe::check_once. But check_once contains both bounded resolve/dial and the independently bounded judge_first_packet read. Thus Rust excludes retry backoff but still includes greeting latency/read timeout. Move the duration capture into the resolve/dial stage, freezing both success and error timing before any greeting read; preserve no-attempt absence and last attempted dial outcome through retry decisions. Carry metadata needed by future consumers to distinguish dial completion from full probe completion.

## Design response to47667a88 (sent ee8f3822)
Recommend keeping Go last-Set event semantics for b_status and ping rather than OR/AND or max; this is reviewer implementation guidance, not new human approval.
- Namespace manager creates independent observers. b_status updates on initially healthy / unhealthy->healthy and previously healthy->unhealthy/disappeared transitions. A never-healthy backend does not create a0child; unchanged health does not keep setting. OR or choosing last snapshot is not equivalent.
- Ping Set ordering is dial-completion ordering, not whole probe completion. No new dial means no new sample; retain prior value under the existing lifetime rule. Failed dial still supplies a duration.
- Preserve source identity/generation fencing in Rust; retained live physical sessions do not themselves authorize retired health publishers.
- Go downBackends metric retention is2hours; purge calls DelBackend. Go health_check_seconds includes GetBackendList, checkHealth, updateHealthResult, purge, subscriber notification; no sleep interval.
This choice needs basic contract evidence in the eventual family implementation, not an expanded matrix. Backend4 remains unqualified.
