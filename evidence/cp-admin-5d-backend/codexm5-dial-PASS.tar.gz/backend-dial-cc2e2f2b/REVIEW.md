# SQL dial duration prerequisite: independent PASS

Exact head: cc2e2f2b1c9d80e5ada934f9b7fcdf2065137c05.
This qualifies collection of the last attempted SQL connect duration only. It does not qualify backend metric exposition, event publication/ordering, status transitions, retention/purge, round timing or the whole four backend families.

## Independent checks on this exact head
- control-external library:166 passed,0 ignored.
- control-topology library:254 passed,6 pre-existing ignored.
- cargo fmt --all --check PASS.
- Both changed packages clippy all-targets/all-features -D warnings PASS.
- Original reviewer slow greeting regression adopted permanently (only formatting/doc lint changed). Executed as part of the full suite with nocapture: healthy=true, sql_dial99.334us, whole stage403.23825ms, scripted greeting delay400ms; PASS. Historical9d6 failed with sql_dial403.517375ms despite the same healthy result; unchanged Go primary implementation measured425.583us/402.59625ms. No rerun of unchanged Go claimed.
- Author new hung greeting test, existing retry-last-attempt test, refused port, invalid/pre-dial address and timeout/fencing suites all passed. The duration propagation branches were independently inspected rather than claiming every failure-duration value was separately measured.

## Verified change
SqlGreetingProbe::check_once_timed starts immediately before the timeout-bounded connector.resolve/connect await and freezes elapsed immediately when that await returns. Success proceeds to a separately bounded greeting read without changing frozen duration. Dial errors and dial timeout return the measured value; fence-first error classification remains. Legacy check_once delegates and returns the same result classification. ClusterHealthNetwork stores each latest attempted dial duration before handling result/retry, so backoff and greeting are excluded; existing pre-attempt exits keep None and later exits retain the last attempted value.

No new metric producer or timestamp ordering was added here. For the later last-Set metric implementation, actual dial completion event ordering must still be preserved (not inferred from whole probe completion); None is no new sample, not resetting prior gauge tozero. That future behavior remains unqualified by this prerequisite receipt.

## Evidence and scope
implementation.diff, raw package/fmt/clippy logs and exact command/head/exit receipts are included. source-check.json proves the three Go reference files unchanged and verifies the author's sealed historical review hash. Original9d6 first-failure archive included unchanged (e2e37a2a3e67e96ba78b66987979bc1192da08f5cab96b5b368206ee74d85521).
No reviewer source edits this round; worktree clean atcc2e2f2b and all local verification processes completed. No matrix expansion, runtime/T3 rerun, push, PR, merge, deployment or broader task closure. Previous b_conn/migration qualifications remain separate.
