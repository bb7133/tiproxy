from pathlib import Path
import subprocess,json,os,sys,time
root=Path(__file__).resolve().parents[4]
work=root/'worktrees/tiproxy-5d-migration-review'
a=Path(__file__).resolve().parent
kind=sys.argv[1]
commands={
'packages':['../../tools/rust/cp-meter-cargo','test','--locked','--manifest-path','rust/Cargo.toml','-p','control-topology','-p','control-external','--lib','--','--nocapture'],
'fmt':['../../tools/rust/cp-meter-cargo','fmt','--manifest-path','rust/Cargo.toml','--all','--','--check'],
'clippy':['../../tools/rust/cp-meter-cargo','clippy','--locked','--manifest-path','rust/Cargo.toml','-p','control-topology','-p','control-external','--all-targets','--all-features','--','-D','warnings']}

env=os.environ.copy();env.update(GOMODCACHE='/Users/bb7133/Projects/gopath/pkg/mod',GOCACHE='/Users/bb7133/Library/Caches/go-build')
cmd=commands[kind]; start=time.time()
with (a/(kind+'.log')).open('w') as f:
 p=subprocess.run(cmd,cwd=work,env=env,stdout=f,stderr=subprocess.STDOUT)
receipt=dict(command=cmd,exit=p.returncode,elapsed=time.time()-start,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip())
(a/(kind+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt)); print((a/(kind+'.log')).read_text()[-2400:])
